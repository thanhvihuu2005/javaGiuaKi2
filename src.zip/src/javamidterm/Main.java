/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Employee> employees = new ArrayList<>();

        while (true) {
            System.out.println("Chon chuc nang:");
            System.out.println("1. Them nhan vien");
            System.out.println("2. Hien thi thong tin nhan vien");
            System.out.println("3. Ghi thong tin nhan vien vao file");
            System.out.println("4. Doc thong tin nhan vien vao file");
            System.out.println("5. Thoat");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Đọc ký tự Enter sau khi nhập số

            switch (choice) {
                case 1:
                    // Thêm nhân viên
                    System.out.println("Nhap thong tin nhan vien:");
                    System.out.print("ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // Đọc ký tự Enter sau khi nhập số
                    System.out.print("FullName: ");
                    String fullName = scanner.nextLine();
                    System.out.print("BirthDay: ");
                    String birthDay = scanner.nextLine();
                    System.out.print("Phone: ");
                    String phone = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Employee type: ");
                    String employeeType = scanner.nextLine();

                    Employee newEmployee = new Employee(id, fullName, birthDay, phone, email, employeeType);
                    employees.add(newEmployee);
                    break;
                case 2:
                    // Hiển thị thông tin nhân viên
                    System.out.println("Thong tin nhan vien");
                    for (Employee employee : employees) {
                        employee.ShowInfo();
                        System.out.println("------------------------");
                    }
                    break;
               case 3:
    // Ghi thông tin nhân viên vào file
    System.out.print("Nhập tên file để ghi (ví dụ: employees.dat): ");
    String fileNameWrite = scanner.nextLine();
    FileHandler.writeToFile(employees, fileNameWrite);
    break;
case 4:
    // Đọc thông tin nhân viên từ file
    System.out.print("Nhập tên file để đọc (ví dụ: employees.dat): ");
    String fileNameRead = scanner.nextLine();
    ArrayList<Employee> employeesFromFile = FileHandler.readFromFile(fileNameRead);
    System.out.println("Thông tin của nhân viên từ file:");
    for (Employee employee : employeesFromFile) {
        employee.ShowInfo();
        System.out.println("------------------------");
    }
    break;
                case 5:
                    // Thoát chương trình
                    System.out.println("Thoat chuong trinh.");
                    System.exit(0);
                default:
                    System.out.println("Sai lua chon, vui long chon lai.");
                    break;
            }
        }
    }
}