/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ArrayList;

public class EmployeeManagement {
    private ArrayList<Employee> employees;

    public EmployeeManagement() {
        this.employees = new ArrayList<>();
    }

    // Thêm một nhân viên mới
    public void addEmployee(Employee employee) {
        employees.add(employee);
    }

    // Hiển thị thông tin của tất cả nhân viên
    public void displayAllEmployees() {
        for (Employee employee : employees) {
            employee.ShowInfo();
            System.out.println("------------------------");
        }
    }

    // Cập nhật thông tin của một nhân viên
    public void updateEmployee(int ID, Employee updatedEmployee) {
        for (Employee employee : employees) {
            if (employee.ID == ID) {
                employee = updatedEmployee;
                return;
            }
        }
        System.out.println("Không tìm thấy nhân viên có ID " + ID);
    }

    // Xóa một nhân viên
    public void deleteEmployee(int ID) {
        for (Employee employee : employees) {
            if (employee.ID == ID) {
                employees.remove(employee);
                System.out.println("Đã xóa nhân viên có ID " + ID);
                return;
            }
        }
        System.out.println("Không tìm thấy nhân viên có ID " + ID);
    }
}