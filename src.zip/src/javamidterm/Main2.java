/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

import java.util.ArrayList;


/**
 *
 * @author THANH
 */
public class Main2 {
    public static void main(String[] args) {
        // Tạo một số đối tượng nhân viên
        Employee employee1 = new Employee(1, "Thanh", "2005-01-01", "123456789", "test1@gmail.com", "Employee");
        Experience experience1 = new Experience(2, "Vu", "2005-05-15", "987654321", "test2@gmail.com", 1, "Java");
        Fresher fresher1 = new Fresher(3, "Viet", "2005-10-20", "456789123", "test3@gmail.com", "2025-03-30", "Excellent", "VKU");
        Intern intern1 = new Intern(4, "Dang", "2005-03-25", "789456123", "test4@gmail.com", "Computer Science", "2023", "VKU");
        Employee employee2 = new Employee(5, "Thanh2", "2005-01-01", "123456789", "test1@gmail.com", "Employee");

        // Thêm các nhân viên vào một ArrayList
        ArrayList<Employee> employees = new ArrayList<>();
        employees.add(employee1);
        employees.add(experience1);
        employees.add(fresher1);
        employees.add(intern1);
        employees.add(employee2);

        // Ghi thông tin nhân viên vào cơ sở dữ liệu SQL Server
        SQLHandler.writeToSQL(employees);

        // Đọc thông tin nhân viên từ cơ sở dữ liệu SQL Server
        ArrayList<Employee> employeesFromSQL = SQLHandler.readFromSQL();

        // Hiển thị thông tin của nhân viên từ cơ sở dữ liệu SQL Server
        System.out.println("Thong tin cua Nhan vien tu SQL");
        for (Employee employee : employeesFromSQL) {
            employee.ShowInfo();
            System.out.println("------------------------");
        }
    }
}