/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

/**
 *
 * @author THANH
 */
public class Experience extends Employee{
    
    
	int ExplnYear;
	String ProSkill;
	
	public Experience(int ID,String FullName, String BirthDay, String Phone,String Email, int ExplnYear,String ProSkill) {
			super(ID,FullName,BirthDay,Phone,Email,"Experience");
			this.ExplnYear = ExplnYear;
			this.ProSkill = ProSkill;
	}
	
	public void ShowInfo() {
		super.ShowInfo();
		System.out.println("ExplnYear "+ ExplnYear);
		System.out.println("ProSkill "+ ProSkill);
	}
    
}
