/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

import java.io.Serializable;

/**
 *
 * @author THANH
 */
public class Employee implements IEmployee,Serializable {
    	protected int ID;
	protected String FullName;
	protected String BirthDay;
	protected String Phone;
	protected String Email;
	protected String Emplyee_type;
	
	protected static int Employee_count = 0;
	
	public Employee(int ID,String FullName, String BirthDay, String Phone,String Email,String Emplyee_type) {
			this.ID = ID;
			this.FullName = FullName;
			this.Phone = Phone;
			this.Email = Email;
			this.Emplyee_type = Emplyee_type;
			Employee_count++;
	}
	
	
	public void ShowInfo() {
		System.out.println("ID "+ ID);
		System.out.println("FullName "+ FullName);
		System.out.println("BirthDay "+ BirthDay);
		System.out.println("Phone "+ Phone);
		System.out.println("Email "+ Email);
		System.out.println("Emplyee_type "+ Emplyee_type);
		
	}
    
}
