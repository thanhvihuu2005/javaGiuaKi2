/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javamidterm;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class SQLHandler {
    private static final String URL = "jdbc:sqlserver://LAPTOP-MPLEJDGS\\SQLEXPRESS:1433;databaseName=MidTerm;encrypt=true;trustServerCertificate=true";
    private static final String USERNAME = "sa";
    private static final String PASSWORD = "sa";

    // Ghi thông tin nhân viên vào cơ sở dữ liệu SQL Server
    public static void writeToSQL(ArrayList<Employee> employees) {
        try (Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            String query = "INSERT INTO Employees (ID, FullName, BirthDay, Phone, Email, Emplyee_type) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement pstmt = con.prepareStatement(query);
            for (Employee employee : employees) {
                pstmt.setInt(1, employee.ID);
                pstmt.setString(2, employee.FullName);
                pstmt.setString(3, employee.BirthDay);
                pstmt.setString(4, employee.Phone);
                pstmt.setString(5, employee.Email);
                pstmt.setString(6, employee.Emplyee_type);
                pstmt.executeUpdate();
            }
            System.out.println("Da ghi thong tin vao co so du lieu");
        } catch (SQLException e) {
            System.out.println("Loi khi ghi thong tin vao SQL" + e.getMessage());
        }
    }

    // Đọc thông tin nhân viên từ cơ sở dữ liệu SQL Server
    public static ArrayList<Employee> readFromSQL() {
        ArrayList<Employee> employees = new ArrayList<>();
        try (Connection con = DriverManager.getConnection(URL, USERNAME, PASSWORD)) {
            String query = "SELECT * FROM Employees";
            PreparedStatement pstmt = con.prepareStatement(query);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int ID = rs.getInt("ID");
                String fullName = rs.getString("FullName");
                String birthDay = rs.getString("BirthDay");
                String phone = rs.getString("Phone");
                String email = rs.getString("Email");
                String employeeType = rs.getString("Emplyee_type");
                Employee employee = new Employee(ID, fullName, birthDay, phone, email, employeeType);
                employees.add(employee);
            }
            System.out.println("Da doc thong tin vao co so du lieu");
        } catch (SQLException e) {
            System.out.println("Loi khi doc thong tin vao SQL " + e.getMessage());
        }
        return employees;
    }
}
